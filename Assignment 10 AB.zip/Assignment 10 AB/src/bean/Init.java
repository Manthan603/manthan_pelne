package bean;

import java.io.Serializable;

public class Init implements Serializable
{
	int i;

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}
	
}
